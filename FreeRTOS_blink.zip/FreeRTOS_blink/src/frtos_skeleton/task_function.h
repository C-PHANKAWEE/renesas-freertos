/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name    : task_function.h
* Description  : declare FreeRTOS entry function header
***********************************************************************************************************************/

#ifndef TASK_FUNCTION_H_
#define TASK_FUNCTION_H_

#endif /* TASK_FUNCTION_H_ */